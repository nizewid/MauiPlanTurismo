﻿namespace MauiDemo
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void CambiarTipoLetra_Clicked(object sender, EventArgs e)
        {
            MenuFlyoutItem menuItem = sender as MenuFlyoutItem;
            string tamanioLetra = menuItem.CommandParameter as string;
            int tamanio = int.Parse(tamanioLetra);
            lblTipoLetra.FontSize = tamanio;
        }

        private void CambiarColorFondo_Clicked(object sender, EventArgs e)
        {
            MenuFlyoutItem menuItem = sender as MenuFlyoutItem;
            string colorFondo = menuItem.CommandParameter as string;
            switch (colorFondo)
            {
                case "Azure":
                    lblTipoLetra.BackgroundColor = Colors.Azure;
                    break;
                case "Beige":
                    lblTipoLetra.BackgroundColor = Colors.Beige;
                    break;
                case "Lavender":
                    lblTipoLetra.BackgroundColor = Colors.Lavender;
                    break;
            }
        }

        private void CambiarColorTexto_Clicked(object sender, EventArgs e)
        {
            MenuFlyoutItem menuItem = sender as MenuFlyoutItem;
            string colorTexto = menuItem.CommandParameter as string;
            switch (colorTexto)
            {
                case "Purple":
                    lblTipoLetra.TextColor = Colors.Purple;
                    break;
                case "Navy":
                    lblTipoLetra.TextColor = Colors.Navy;
                    break;
                case "Magenta":
                    lblTipoLetra.TextColor = Colors.Magenta;
                    break;
                case "DarkRed":
                    lblTipoLetra.TextColor = Colors.DarkRed;
                    break;
            }
        }
    }

}
