namespace ScrumMaui.Views.Spring;

public partial class MakeSpring : ContentPage
{
	public MakeSpring()
	{
		InitializeComponent();
	}
}