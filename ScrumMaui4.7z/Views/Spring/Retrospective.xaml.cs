namespace ScrumMaui.Views.Spring;

public partial class Retrospective : ContentPage
{
	public Retrospective()
	{
		InitializeComponent();
	}
}