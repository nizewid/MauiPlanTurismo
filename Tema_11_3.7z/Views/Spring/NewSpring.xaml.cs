namespace ScrumMaui.Views.Spring;

public partial class NewSpring : ContentPage
{
	public NewSpring()
	{
		InitializeComponent();
	}
    private void btnCreateBacklog_Clicked(object sender, EventArgs e)
    {
        // Navigate to the SpringList page
        Shell.Current.Navigation.PushModalAsync(new CreateSpringList());
    }
}