namespace ScrumMaui.Views.Spring;

public partial class SpringPanel : ContentPage
{
	public SpringPanel()
	{
		InitializeComponent();
	}
}