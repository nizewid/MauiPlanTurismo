namespace ScrumMaui.Views.Backlog;

public partial class BacklogPanel : ContentPage
{
	public BacklogPanel()
	{
		InitializeComponent();
	}
}