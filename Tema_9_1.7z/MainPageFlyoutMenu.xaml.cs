namespace MauiPlanTurismo;

public partial class MainPageFlyoutMenu : ContentPage
{
	public MainPageFlyoutMenu()
	{
		InitializeComponent();
	}
}