namespace MauiPlanTurismo.Views.Destinations;

public partial class TabDestinyPrices : ContentPage
{
	public TabDestinyPrices()
	{
		InitializeComponent();
	}
}