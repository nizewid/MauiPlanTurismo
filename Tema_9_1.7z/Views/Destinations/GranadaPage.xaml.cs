namespace MauiPlanTurismo.Views.Destinations;

public partial class GranadaPage : ContentPage
{
	public GranadaPage()
	{
		InitializeComponent();
	}
}