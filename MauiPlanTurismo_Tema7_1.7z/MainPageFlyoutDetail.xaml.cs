namespace MauiPlanTurismo;

public partial class MainPageFlyoutDetail : ContentPage
{
	public MainPageFlyoutDetail()
	{
		InitializeComponent();
	}
}