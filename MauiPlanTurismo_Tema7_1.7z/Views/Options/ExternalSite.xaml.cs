namespace MauiPlanTurismo.Views.Options;

public partial class ExternalSite : ContentPage
{
	public ExternalSite()
	{
		InitializeComponent();
	}
}