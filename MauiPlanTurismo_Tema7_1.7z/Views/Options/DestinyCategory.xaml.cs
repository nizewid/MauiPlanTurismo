namespace MauiPlanTurismo.Views.Options;

public partial class DestinyCategory : ContentPage
{
	public DestinyCategory()
	{
		InitializeComponent();
	}
}